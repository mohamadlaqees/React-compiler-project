package AST.Program.Node;

public interface Node {
    String generateJs();
}

