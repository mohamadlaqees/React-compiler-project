package AST.Program.Expression;

import AST.Program.Node.Node;

public abstract class Expression implements Node {
    @Override
    public String generateJs() {
        return null;
    }
}
